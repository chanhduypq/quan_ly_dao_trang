<?php
class Common_Bootstrap extends Zend_Application_Module_Bootstrap
{
	
}
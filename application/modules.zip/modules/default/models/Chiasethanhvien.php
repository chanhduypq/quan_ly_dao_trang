<?php

class Default_Model_Chiasethanhvien extends Default_Model_Common 
{

    public $_name = "chiase_thanhvien";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>